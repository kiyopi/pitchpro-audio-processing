/**
 * Library version information
 * Auto-synced with package.json during build
 */
export declare const VERSION = "1.3.2";
/**
 * Version display string for debug logs
 */
export declare const VERSION_STRING = "PitchPro v1.3.2";
/**
 * Build timestamp (will be replaced during build)
 */
export declare const BUILD_TIMESTAMP: string;
//# sourceMappingURL=version.d.ts.map