# PitchPro v1.1.5 - ライブラリファイル

## 📦 含まれるファイル

### メインファイル（選択して使用）
- `dist/pitchpro.umd.js` - UMD形式（推奨・ブラウザ用）
- `dist/index.esm.js` - ESM形式（モジュール用）
- `dist/index.js` - CommonJS形式（Node.js用）

### 型定義ファイル
- `dist/index.d.ts` - TypeScript型定義

## 🚀 使用方法

### 1. HTML直接読み込み
```html
<script src="dist/pitchpro.umd.js"></script>
<script>
  const audioDetector = new PitchPro.AudioDetectionComponent({...});
</script>
```

### 2. ES6モジュール
```html
<script type="module">
  import { AudioDetectionComponent } from './dist/index.esm.js';
  const audioDetector = new AudioDetectionComponent({...});
</script>
```

## ✨ v1.1.5新機能
- updateSelectors()にUIリセット機能追加
- 音量バー切り替え時の表示残留バグ修正
- 包括的UI要素自動リセット機能

## 📚 詳細ドキュメント
- アップデートガイド: https://github.com/kiyopi/pitchpro-audio-processing/blob/main/PITCH_TRAINING_APP_UPDATE_GUIDE.md
- 完全ドキュメント: https://github.com/kiyopi/pitchpro-audio-processing/blob/main/README.md